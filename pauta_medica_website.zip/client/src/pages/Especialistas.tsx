import { Link } from "wouter";
import { ArrowRight, Stethoscope } from "lucide-react";

export default function Especialistas() {
  // Mock data for specialists - in a real app, this would come from a CMS or API
  const specialists = [
    {
      name: "Dr. Roberto Mendes",
      specialty: "Cardiologia Intervencionista",
      crm: "CRM-SP 123.456",
      bio: "Especialista em procedimentos minimamente invasivos. Fonte frequente para pautas sobre saúde do coração e novas tecnologias.",
      topics: ["Infarto", "Stents", "Prevenção Cardiovascular"]
    },
    {
      name: "Dra. Juliana Paiva",
      specialty: "Dermatologia Avançada",
      crm: "CRM-SP 234.567",
      bio: "Referência em tratamentos estéticos e doenças de pele. Aborda temas de autocuidado com rigor científico.",
      topics: ["Skincare", "Câncer de Pele", "Tecnologias a Laser"]
    },
    {
      name: "Dr. André Silva",
      specialty: "Oncologia Clínica",
      crm: "CRM-SP 345.678",
      bio: "Focado em imunoterapia e tratamento humanizado. Voz ativa na conscientização sobre prevenção do câncer.",
      topics: ["Imunoterapia", "Prevenção", "Saúde Pública"]
    },
    {
      name: "Dra. Carla Nunes",
      specialty: "Pediatria e Hebiatria",
      crm: "CRM-SP 456.789",
      bio: "Especialista em desenvolvimento infantil e saúde do adolescente. Comunicação clara para pais e cuidadores.",
      topics: ["Vacinação", "Desenvolvimento", "Saúde Escolar"]
    },
    {
      name: "Dr. Marcos Costa",
      specialty: "Cirurgia Plástica",
      crm: "CRM-SP 567.890",
      bio: "Membro titular da SBCP. Foco em cirurgia reparadora e estética com segurança e ética.",
      topics: ["Segurança em Cirurgia", "Autoestima", "Reconstrução"]
    },
    {
      name: "Dra. Fernanda Lima",
      specialty: "Infectologia",
      crm: "CRM-SP 678.901",
      bio: "Pesquisadora em doenças tropicais e virologia. Atuação destacada em gestão de crises sanitárias.",
      topics: ["Vacinas", "Epidemias", "Vírus Emergentes"]
    }
  ];

  return (
    <div className="pt-20 pb-32">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="max-w-4xl mb-20">
          <span className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4 block">Hub de Porta-Vozes</span>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-8">
            VOZES DE <br/> <span className="text-neutral-400">AUTORIDADE</span>.
          </h1>
          <p className="text-xl text-neutral-600 font-light max-w-2xl leading-relaxed">
            Acesse nosso banco exclusivo de especialistas prontos para entrevistas, 
            validação de pautas e produção de conteúdo com rigor científico.
          </p>
        </div>

        {/* Specialists Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-neutral-200 border border-neutral-200 mb-20">
          {specialists.map((doctor, index) => (
            <div key={index} className="bg-white p-10 hover:bg-neutral-50 transition-colors group flex flex-col h-full">
              <div className="mb-6">
                <div className="w-12 h-12 bg-neutral-100 rounded-full flex items-center justify-center mb-4 group-hover:bg-black group-hover:text-white transition-colors">
                  <Stethoscope className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold mb-1">{doctor.name}</h3>
                <p className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-2">{doctor.specialty}</p>
                <p className="text-xs text-neutral-400 font-mono mb-4">{doctor.crm}</p>
              </div>
              
              <p className="text-neutral-600 leading-relaxed mb-6 flex-grow">
                {doctor.bio}
              </p>

              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {doctor.topics.map((topic, i) => (
                    <span key={i} className="text-xs font-medium bg-neutral-100 px-2 py-1 text-neutral-600">
                      {topic}
                    </span>
                  ))}
                </div>
                
                <Link href="/contato">
                  <a className="inline-flex items-center text-sm font-bold uppercase tracking-widest hover:text-neutral-600 transition-colors mt-4">
                    Solicitar Entrevista
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </a>
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="bg-black text-white p-12 md:p-20 text-center">
          <h2 className="text-3xl md:text-4xl font-black tracking-tighter mb-6">
            É MÉDICO E QUER FAZER PARTE DO HUB?
          </h2>
          <p className="text-neutral-400 text-lg mb-10 max-w-2xl mx-auto">
            Junte-se a um grupo seleto de especialistas que são referência na mídia nacional.
            Gestão de imagem completa e oportunidades de visibilidade.
          </p>
          <Link href="/contato">
            <a className="inline-flex items-center justify-center px-10 py-5 bg-white text-black text-sm font-bold uppercase tracking-widest hover:bg-neutral-200 transition-colors">
              Aplicar para o Hub
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}
