import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export default function Servicos() {
  const services = [
    {
      category: "Relacionamento com a Mídia",
      detail: "Disparos de Press Release, Gestão de Relacionamento com Jornalistas, Conexões com Veículos (Tier 1 e Especializados).",
      objective: "Garantir a inserção proativa e estratégica de pautas."
    },
    {
      category: "Monitoramento e Oportunidades",
      detail: "Monitoramento \"Always On\" de notícias relevantes, Indexação de Pautas e Oportunidades, Inserção em Notícias de Última Hora.",
      objective: "Capturar o momento certo para posicionar o especialista."
    },
    {
      category: "Gestão de Imagem e Conteúdo",
      detail: "Gestão de Imagem, Media Training para Entrevistas (TV, Rádio, Podcast), Produção de Conteúdo para Mídia.",
      objective: "Preparar o porta-voz e garantir a qualidade da mensagem."
    },
    {
      category: "Hub de Porta-Vozes",
      detail: "Conexão imediata com médicos de diversas especialidades para validação, produção de notícias e entrevistas.",
      objective: "Fornecer a voz médica e a credibilidade científica que o seu projeto ou pauta exige."
    },
    {
      category: "Mensuração de Resultados",
      detail: "Clipagem e Análise de Mídia.",
      objective: "Comprovar o retorno sobre o investimento (ROI) em reputação."
    }
  ];

  return (
    <div className="pt-20 pb-32">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mb-20">
          <span className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4 block">O Que Fazemos</span>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-8">
            VISIBILIDADE E <br/> CREDIBILIDADE <span className="text-neutral-400">ALWAYS ON</span>.
          </h1>
          <p className="text-xl text-neutral-600 font-light max-w-2xl">
            Oferecemos um ciclo completo de gestão de imagem e relacionamento com a mídia, 
            garantindo a presença constante e qualificada de nossos clientes.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b-2 border-black">
                <th className="py-6 pr-8 text-lg font-bold uppercase tracking-widest w-1/4">Categoria</th>
                <th className="py-6 pr-8 text-lg font-bold uppercase tracking-widest w-2/4">Serviço Detalhado</th>
                <th className="py-6 text-lg font-bold uppercase tracking-widest w-1/4">Objetivo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-200">
              {services.map((service, index) => (
                <tr key={index} className="group hover:bg-neutral-50 transition-colors">
                  <td className="py-8 pr-8 align-top font-bold text-lg">{service.category}</td>
                  <td className="py-8 pr-8 align-top text-neutral-600 leading-relaxed">{service.detail}</td>
                  <td className="py-8 align-top text-neutral-500 italic">{service.objective}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-20 p-12 bg-black text-white flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-2">Precisa de uma solução personalizada?</h3>
            <p className="text-neutral-400">Analisamos o seu momento e desenhamos a estratégia ideal.</p>
          </div>
          <Link href="/contato">
            <a className="inline-flex items-center justify-center px-8 py-4 bg-white text-black text-sm font-bold uppercase tracking-widest hover:bg-neutral-200 transition-colors whitespace-nowrap">
              Falar com Consultor
              <ArrowRight className="ml-2 w-4 h-4" />
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}
