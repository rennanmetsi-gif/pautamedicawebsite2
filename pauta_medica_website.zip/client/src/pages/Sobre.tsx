import { Link } from "wouter";

export default function Sobre() {
  return (
    <div className="pt-20 pb-32">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="max-w-4xl mb-24">
          <span className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4 block">Quem Somos</span>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-8">
            A ASSESSORIA QUE <br/> ENTENDE DE <span className="text-neutral-400">SAÚDE</span>.
          </h1>
          <p className="text-2xl text-neutral-600 font-light leading-relaxed border-l-4 border-black pl-8 py-2">
            "Nosso compromisso é fazer com que a saúde seja comunicada com a seriedade e a precisão que ela exige."
          </p>
        </div>

        {/* Mission Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-32">
          {[
            {
              title: "Conectar",
              desc: "Aproximar a categoria médica do jornalismo, facilitando o acesso a fontes de informação confiáveis."
            },
            {
              title: "Qualificar",
              desc: "Garantir informação baseada em evidências, combatendo o 'terrorismo científico' e a desinformação."
            },
            {
              title: "Potencializar",
              desc: "Trabalhar o PR, Awareness e Autoridade de nossos clientes, transformando-os em referências."
            }
          ].map((item, i) => (
            <div key={i} className="border-t border-black pt-8">
              <span className="text-4xl font-black text-neutral-200 mb-4 block">0{i + 1}</span>
              <h3 className="text-2xl font-bold mb-4">{item.title}</h3>
              <p className="text-neutral-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

        {/* Team Section */}
        <div className="bg-neutral-100 p-12 md:p-24 -mx-6 md:-mx-24 mb-32">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-4xl font-black tracking-tighter mb-16 text-center">NOSSA EQUIPE MULTIDISCIPLINAR</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  role: "Jornalistas Especializados",
                  focus: "Identificação de pautas, redação científica e relacionamento com editores."
                },
                {
                  role: "Relações Públicas (RP)",
                  focus: "Gestão de imagem, posicionamento estratégico e mediação de crises."
                },
                {
                  role: "Publicitários",
                  focus: "Criação de narrativas, produção de conteúdo e campanhas de visibilidade."
                }
              ].map((member, i) => (
                <div key={i} className="bg-white p-8 shadow-sm">
                  <h3 className="text-xl font-bold mb-4 border-b border-neutral-200 pb-4">{member.role}</h3>
                  <p className="text-neutral-600 text-sm leading-relaxed">{member.focus}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Specialties List */}
        <div>
          <h2 className="text-3xl font-black tracking-tighter mb-12">ESPECIALIDADES ATENDIDAS</h2>
          <div className="columns-1 md:columns-2 lg:columns-4 gap-8 space-y-4">
            {[
              "Dermatologia", "Infectologia", "Cirurgia Plástica", "Cirurgia Vascular",
              "Hematologia", "Oncologia", "Ginecologia", "Obstetrícia",
              "Cardiologia", "Pneumologia", "Neurologia", "Psiquiatria",
              "Ortopedia", "Endocrinologia", "Pediatria", "Oftalmologia"
            ].map((spec, i) => (
              <div key={i} className="break-inside-avoid py-3 border-b border-neutral-200 text-lg font-medium text-neutral-800">
                {spec}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
