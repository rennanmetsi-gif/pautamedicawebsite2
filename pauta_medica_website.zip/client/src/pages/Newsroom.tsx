import { Link } from "wouter";
import { ArrowRight, Calendar, Download, FileText, Search } from "lucide-react";

export default function Newsroom() {
  // Mock data for news/releases
  const news = [
    {
      id: 1,
      type: "Press Release",
      date: "07 Dez 2025",
      title: "Pauta Médica lança Hub de Porta-Vozes com mais de 50 especialistas",
      excerpt: "Nova plataforma conecta jornalistas a médicos validados para entrevistas e pautas de saúde em tempo real.",
      tags: ["Institucional", "Inovação"]
    },
    {
      id: 2,
      type: "Clipping",
      date: "05 Dez 2025",
      title: "Dr. Roberto Mendes discute aumento de infartos em jovens na CNN Brasil",
      excerpt: "Cardiologista alerta para os riscos do sedentarismo e estresse em entrevista exclusiva ao vivo.",
      tags: ["Cardiologia", "Mídia Tier 1"]
    },
    {
      id: 3,
      type: "Artigo de Opinião",
      date: "01 Dez 2025",
      title: "O perigo das fake news na oncologia: como a desinformação mata",
      excerpt: "Dr. André Silva assina artigo na Folha de S.Paulo sobre a importância da evidência científica no tratamento do câncer.",
      tags: ["Oncologia", "Combate à Desinformação"]
    },
    {
      id: 4,
      type: "Press Release",
      date: "28 Nov 2025",
      title: "Clínica DermatoHealth inaugura unidade com tecnologia pioneira em laser",
      excerpt: "Novo espaço em São Paulo traz equipamentos inéditos para tratamento de melasma e cicatrizes.",
      tags: ["Dermatologia", "Tecnologia"]
    },
    {
      id: 5,
      type: "Clipping",
      date: "20 Nov 2025",
      title: "Vacinação infantil: Dra. Carla Nunes tira dúvidas no Jornal Hoje",
      excerpt: "Pediatra explica o calendário vacinal e desmistifica reações adversas em reportagem especial.",
      tags: ["Pediatria", "Vacinação"]
    }
  ];

  return (
    <div className="pt-20 pb-32">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="max-w-4xl mb-16">
          <span className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4 block">Sala de Imprensa</span>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-8">
            NEWSROOM & <br/> <span className="text-neutral-400">RELEASES</span>.
          </h1>
          <p className="text-xl text-neutral-600 font-light max-w-2xl leading-relaxed">
            Acompanhe as últimas notícias, lançamentos e destaques de nossos clientes na mídia. 
            Conteúdo pronto para jornalistas e parceiros.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-6 mb-16 border-y border-neutral-200 py-8">
          <div className="relative flex-grow">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input 
              type="text" 
              placeholder="Buscar por tema, médico ou especialidade..." 
              className="w-full bg-neutral-50 border border-neutral-200 pl-12 pr-4 py-4 focus:outline-none focus:border-black transition-colors"
            />
          </div>
          <div className="flex gap-4 overflow-x-auto pb-2 md:pb-0">
            {["Todos", "Press Releases", "Clipping", "Artigos"].map((filter, i) => (
              <button 
                key={i}
                className={`px-6 py-4 text-sm font-bold uppercase tracking-widest whitespace-nowrap border transition-colors ${i === 0 ? 'bg-black text-white border-black' : 'bg-white text-neutral-500 border-neutral-200 hover:border-black hover:text-black'}`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 gap-12">
          {news.map((item) => (
            <div key={item.id} className="group border-b border-neutral-200 pb-12 last:border-0">
              <div className="flex flex-col md:flex-row gap-8 items-start">
                {/* Date & Type */}
                <div className="md:w-48 flex-shrink-0">
                  <div className="flex items-center text-neutral-500 mb-2">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span className="text-sm font-mono">{item.date}</span>
                  </div>
                  <span className={`inline-block px-3 py-1 text-xs font-bold uppercase tracking-widest ${item.type === 'Press Release' ? 'bg-black text-white' : 'bg-neutral-100 text-neutral-600'}`}>
                    {item.type}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-grow">
                  <h2 className="text-3xl font-bold mb-4 group-hover:text-neutral-600 transition-colors cursor-pointer">
                    {item.title}
                  </h2>
                  <p className="text-neutral-600 text-lg leading-relaxed mb-6 max-w-3xl">
                    {item.excerpt}
                  </p>
                  
                  <div className="flex flex-wrap gap-4 items-center justify-between">
                    <div className="flex gap-2">
                      {item.tags.map((tag, i) => (
                        <span key={i} className="text-xs font-medium text-neutral-400">#{tag}</span>
                      ))}
                    </div>
                    
                    <div className="flex gap-4">
                      {item.type === 'Press Release' && (
                        <button className="inline-flex items-center text-sm font-bold uppercase tracking-widest hover:text-neutral-600 transition-colors">
                          <Download className="w-4 h-4 mr-2" />
                          Baixar Release
                        </button>
                      )}
                      <button className="inline-flex items-center text-sm font-bold uppercase tracking-widest hover:text-neutral-600 transition-colors">
                        Ler Completo
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Press Kit CTA */}
        <div className="mt-20 bg-neutral-100 p-12 md:p-16 flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <div className="flex items-center mb-4">
              <FileText className="w-8 h-8 mr-4" />
              <h3 className="text-2xl font-bold">Press Kit Institucional</h3>
            </div>
            <p className="text-neutral-600 max-w-xl">
              Faça o download do nosso media kit completo, com logos em alta resolução, 
              fotos dos porta-vozes e boilerplates da Pauta Médica.
            </p>
          </div>
          <button className="inline-flex items-center justify-center px-8 py-4 bg-white border border-neutral-300 text-black text-sm font-bold uppercase tracking-widest hover:bg-black hover:text-white hover:border-black transition-colors whitespace-nowrap">
            Download Press Kit
            <Download className="ml-2 w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
