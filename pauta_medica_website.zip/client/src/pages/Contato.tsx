import { Mail, MapPin, Phone } from "lucide-react";

export default function Contato() {
  return (
    <div className="pt-20 pb-32">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Contact Info */}
          <div>
            <span className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4 block">Fale Conosco</span>
            <h1 className="text-5xl md:text-6xl font-black tracking-tighter mb-8">
              VAMOS CONSTRUIR <br/> SUA <span className="text-neutral-400">AUTORIDADE</span>?
            </h1>
            <p className="text-xl text-neutral-600 font-light mb-12 leading-relaxed">
              Agende uma reunião para um diagnóstico de mídia gratuito e personalizado. 
              Entenda como podemos transformar sua expertise em notícia.
            </p>

            <div className="space-y-8">
              <div className="flex items-start">
                <Phone className="w-6 h-6 mr-6 mt-1" />
                <div>
                  <h3 className="text-lg font-bold uppercase tracking-widest mb-1">Telefone</h3>
                  <p className="text-neutral-600 text-lg">(11) 99999-9999</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Mail className="w-6 h-6 mr-6 mt-1" />
                <div>
                  <h3 className="text-lg font-bold uppercase tracking-widest mb-1">E-mail</h3>
                  <p className="text-neutral-600 text-lg">contato@pautamedica.com.br</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <MapPin className="w-6 h-6 mr-6 mt-1" />
                <div>
                  <h3 className="text-lg font-bold uppercase tracking-widest mb-1">Endereço</h3>
                  <p className="text-neutral-600 text-lg">
                    Av. Paulista, 1000 - Bela Vista<br/>
                    São Paulo - SP
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="bg-neutral-50 p-10 md:p-16 border border-neutral-200">
            <h2 className="text-2xl font-bold mb-8">Envie uma mensagem</h2>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase tracking-widest text-neutral-500">Nome</label>
                  <input type="text" className="w-full bg-white border border-neutral-300 p-4 focus:outline-none focus:border-black transition-colors" placeholder="Seu nome" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold uppercase tracking-widest text-neutral-500">E-mail</label>
                  <input type="email" className="w-full bg-white border border-neutral-300 p-4 focus:outline-none focus:border-black transition-colors" placeholder="seu@email.com" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-bold uppercase tracking-widest text-neutral-500">Assunto</label>
                <select className="w-full bg-white border border-neutral-300 p-4 focus:outline-none focus:border-black transition-colors appearance-none">
                  <option>Quero ser cliente</option>
                  <option>Sou jornalista (Imprensa)</option>
                  <option>Parcerias</option>
                  <option>Outros</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold uppercase tracking-widest text-neutral-500">Mensagem</label>
                <textarea className="w-full bg-white border border-neutral-300 p-4 h-40 focus:outline-none focus:border-black transition-colors resize-none" placeholder="Como podemos ajudar?"></textarea>
              </div>

              <button type="submit" className="w-full bg-black text-white font-bold uppercase tracking-widest py-5 hover:bg-neutral-800 transition-colors">
                Enviar Mensagem
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
