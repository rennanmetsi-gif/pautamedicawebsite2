import { Link } from "wouter";
import { ArrowUpRight, BarChart3, TrendingUp, Users } from "lucide-react";

export default function Cases() {
  const cases = [
    {
      title: "Nova Técnica em Cirurgia Plástica",
      client: "Dr. Marcos Costa",
      vehicle: "Folha de S.Paulo",
      category: "Cirurgia Plástica",
      impact: "Capa do caderno de Saúde + 500k views online",
      desc: "Estratégia de lançamento de técnica reconstrutiva inovadora. Foco em utilidade pública e segurança do paciente."
    },
    {
      title: "Alerta sobre Vírus Sazonal",
      client: "Dra. Fernanda Lima",
      vehicle: "Jornal Nacional (TV Globo)",
      category: "Infectologia",
      impact: "Entrevista ao vivo + 30% aumento em buscas",
      desc: "Posicionamento rápido durante surto viral. Media training intensivo para garantir clareza e calma na transmissão da mensagem."
    },
    {
      title: "Avanços na Imunoterapia",
      client: "Dr. André Silva",
      vehicle: "Veja Saúde",
      category: "Oncologia",
      impact: "Matéria de 4 páginas + Podcast exclusivo",
      desc: "Tradução de paper científico complexo para linguagem acessível. Estabelecimento do médico como autoridade em inovação."
    },
    {
      title: "Prevenção Cardiovascular em Jovens",
      client: "Dr. Roberto Mendes",
      vehicle: "CNN Brasil",
      category: "Cardiologia",
      impact: "Série de 3 inserções + Repercussão em Rádio",
      desc: "Campanha de conscientização focada em mudança de estilo de vida. Abordagem preventiva com dados alarmantes."
    }
  ];

  return (
    <div className="pt-20 pb-32">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="max-w-4xl mb-20">
          <span className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4 block">Resultados Reais</span>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-8">
            IMPACTO QUE <br/> GERA <span className="text-neutral-400">VALOR</span>.
          </h1>
          <p className="text-xl text-neutral-600 font-light max-w-2xl leading-relaxed">
            A credibilidade se constrói com resultados consistentes. Veja como transformamos 
            conhecimento técnico em pautas de relevância nacional.
          </p>
        </div>

        {/* Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24 border-y border-neutral-200 py-12">
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start mb-4 text-neutral-400">
              <BarChart3 className="w-6 h-6 mr-2" />
              <span className="text-sm font-bold uppercase tracking-widest">Média Mensal</span>
            </div>
            <div className="text-5xl font-black tracking-tighter mb-2">+40</div>
            <p className="text-neutral-600">Matérias indexadas por cliente</p>
          </div>
          
          <div className="text-center md:text-left border-t md:border-t-0 md:border-l border-neutral-200 pt-8 md:pt-0 md:pl-8">
            <div className="flex items-center justify-center md:justify-start mb-4 text-neutral-400">
              <TrendingUp className="w-6 h-6 mr-2" />
              <span className="text-sm font-bold uppercase tracking-widest">Qualidade</span>
            </div>
            <div className="text-5xl font-black tracking-tighter mb-2">85%</div>
            <p className="text-neutral-600">Inserções em veículos Tier 1</p>
          </div>
          
          <div className="text-center md:text-left border-t md:border-t-0 md:border-l border-neutral-200 pt-8 md:pt-0 md:pl-8">
            <div className="flex items-center justify-center md:justify-start mb-4 text-neutral-400">
              <Users className="w-6 h-6 mr-2" />
              <span className="text-sm font-bold uppercase tracking-widest">Alcance</span>
            </div>
            <div className="text-5xl font-black tracking-tighter mb-2">ROI</div>
            <p className="text-neutral-600">Alto retorno em reputação e leads</p>
          </div>
        </div>

        {/* Cases List */}
        <div className="space-y-px bg-neutral-200 border border-neutral-200">
          {cases.map((item, index) => (
            <div key={index} className="bg-white p-8 md:p-12 hover:bg-neutral-50 transition-colors group">
              <div className="flex flex-col md:flex-row justify-between md:items-start gap-8">
                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-xs font-bold uppercase tracking-widest bg-black text-white px-2 py-1">
                      {item.category}
                    </span>
                    <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">
                      {item.vehicle}
                    </span>
                  </div>
                  
                  <h3 className="text-3xl font-bold mb-4 group-hover:text-neutral-700 transition-colors">
                    {item.title}
                  </h3>
                  
                  <p className="text-neutral-600 leading-relaxed mb-6 max-w-2xl">
                    {item.desc}
                  </p>
                  
                  <div className="flex items-center text-sm font-medium text-neutral-800">
                    <span className="w-2 h-2 bg-green-500 rounded-full mr-3"></span>
                    Resultado: {item.impact}
                  </div>
                </div>

                <div className="md:text-right">
                  <p className="text-sm font-bold uppercase tracking-widest text-neutral-400 mb-1">Cliente</p>
                  <p className="text-lg font-bold">{item.client}</p>
                  
                  <button className="mt-8 inline-flex items-center justify-center w-12 h-12 rounded-full border border-neutral-200 group-hover:bg-black group-hover:border-black group-hover:text-white transition-all">
                    <ArrowUpRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-20 text-center">
          <p className="text-xl text-neutral-600 font-light mb-8">
            Quer ver sua marca alcançando resultados como estes?
          </p>
          <Link href="/contato">
            <a className="inline-flex items-center justify-center px-10 py-5 bg-black text-white text-sm font-bold uppercase tracking-widest hover:bg-neutral-800 transition-colors">
              Solicitar Estudo de Caso
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
}
