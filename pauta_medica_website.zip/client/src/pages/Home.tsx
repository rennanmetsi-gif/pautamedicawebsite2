import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, Globe, Users, Award, Newspaper } from "lucide-react";

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="min-h-[90vh] flex items-center justify-center bg-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(#e5e5e5_1px,transparent_1px)] [background-size:16px_16px] opacity-30"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div 
            initial="initial"
            animate="animate"
            variants={staggerContainer}
            className="max-w-4xl"
          >
            <motion.span 
              variants={fadeIn}
              className="inline-block py-1 px-3 border border-black text-xs font-bold uppercase tracking-widest mb-8"
            >
              Assessoria de Imprensa Especializada
            </motion.span>
            
            <motion.h1 
              variants={fadeIn}
              className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9] mb-8"
            >
              AUTORIDADE <br/>
              <span className="text-neutral-400">MÉDICA</span> NA <br/>
              GRANDE MÍDIA.
            </motion.h1>
            
            <motion.p 
              variants={fadeIn}
              className="text-xl md:text-2xl text-neutral-600 font-light max-w-2xl mb-12 leading-relaxed"
            >
              Transformamos médicos, clínicas e healthtechs em referências nacionais. 
              Comunicação baseada em evidência, ética e resultados de alto impacto.
            </motion.p>
            
            <motion.div variants={fadeIn} className="flex flex-col sm:flex-row gap-4">
              <Link href="/contato">
                <a className="inline-flex items-center justify-center px-8 py-4 bg-black text-white text-sm font-bold uppercase tracking-widest hover:bg-neutral-800 transition-colors group">
                  Agendar Diagnóstico
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </a>
              </Link>
              <Link href="/servicos">
                <a className="inline-flex items-center justify-center px-8 py-4 border border-black text-black text-sm font-bold uppercase tracking-widest hover:bg-neutral-50 transition-colors">
                  Conhecer Serviços
                </a>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-32 bg-black text-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-black tracking-tighter mb-8 leading-tight">
                A PONTE ENTRE <br/>
                CIÊNCIA E MÍDIA.
              </h2>
              <div className="w-20 h-1 bg-white mb-8"></div>
            </div>
            <div className="space-y-8">
              <p className="text-xl font-light text-neutral-300 leading-relaxed">
                A Pauta Médica nasceu para elevar o nível da comunicação em saúde no Brasil. 
                Combatemos o "terrorismo científico" com informação qualificada e transformamos 
                especialistas em fontes confiáveis para a imprensa.
              </p>
              <ul className="space-y-4">
                {[
                  "Conexão direta com jornalistas de Tier 1",
                  "Conteúdo 100% baseado em evidências",
                  "Foco em PR, Awareness e Autoridade"
                ].map((item, i) => (
                  <li key={i} className="flex items-center text-lg font-medium">
                    <CheckCircle2 className="w-6 h-6 mr-4 text-neutral-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Differentials Grid */}
      <section className="py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="mb-20">
            <span className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-4 block">Por que Pauta Médica?</span>
            <h2 className="text-4xl md:text-5xl font-black tracking-tighter">EXPERTISE QUE FAZ A DIFERENÇA</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-neutral-200 border border-neutral-200">
            {[
              {
                icon: Globe,
                title: "Visão de Ecossistema",
                desc: "Atendemos toda a cadeia: médicos, clínicas, hospitais, farmacêuticas e healthtechs."
              },
              {
                icon: Users,
                title: "Hub de Especialistas",
                desc: "Acesso imediato a porta-vozes médicos de diversas especialidades para validação."
              },
              {
                icon: Award,
                title: "Raiz na Saúde",
                desc: "Fundada por especialistas em comunicação médica. Entendemos o CFM e a ética."
              },
              {
                icon: Newspaper,
                title: "Foco em Evidência",
                desc: "Rigor na curadoria da informação. Zero sensacionalismo, 100% credibilidade."
              }
            ].map((item, i) => (
              <div key={i} className="bg-white p-10 hover:bg-neutral-50 transition-colors group">
                <item.icon className="w-10 h-10 mb-6 text-black group-hover:scale-110 transition-transform duration-300" />
                <h3 className="text-xl font-bold mb-4">{item.title}</h3>
                <p className="text-neutral-600 leading-relaxed text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats / Social Proof */}
      <section className="py-32 bg-neutral-100 border-y border-neutral-200">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            {[
              { number: "+15", label: "Anos de Experiência" },
              { number: "Tier 1", label: "Veículos Indexados" },
              { number: "100%", label: "Foco em Saúde" }
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-6xl md:text-7xl font-black tracking-tighter mb-4">{stat.number}</div>
                <div className="text-sm font-bold uppercase tracking-widest text-neutral-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-white">
        <div className="container mx-auto px-6 text-center max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-6xl font-black tracking-tighter mb-8">
            PRONTO PARA SER REFERÊNCIA?
          </h2>
          <p className="text-xl text-neutral-600 font-light mb-12">
            Agende um diagnóstico de mídia gratuito e descubra o potencial da sua autoridade.
          </p>
          <Link href="/contato">
            <a className="inline-flex items-center justify-center px-10 py-5 bg-black text-white text-base font-bold uppercase tracking-widest hover:bg-neutral-800 transition-colors">
              Falar com Especialista
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
