import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import Layout from "./components/Layout";
import { ThemeProvider } from "./contexts/ThemeContext";
import Cases from "./pages/Cases";
import Contato from "./pages/Contato";
import Especialistas from "./pages/Especialistas";
import Home from "./pages/Home";
import Newsroom from "./pages/Newsroom";
import NotFound from "./pages/NotFound";
import Servicos from "./pages/Servicos";
import Sobre from "./pages/Sobre";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/sobre" component={Sobre} />
        <Route path="/servicos" component={Servicos} />
        <Route path="/especialistas" component={Especialistas} />
        <Route path="/cases" component={Cases} />
        <Route path="/newsroom" component={Newsroom} />
        <Route path="/contato" component={Contato} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
