import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/sobre", label: "Quem Somos" },
    { href: "/servicos", label: "Serviços" },
    { href: "/especialistas", label: "Especialistas" },
    { href: "/cases", label: "Cases" },
    { href: "/newsroom", label: "Newsroom" },
    { href: "/contato", label: "Contato" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans selection:bg-black selection:text-white">
      <header className="fixed top-0 w-full z-50 bg-background/90 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <Link href="/">
            <a className="text-2xl font-black tracking-tighter hover:opacity-80 transition-opacity">
              PAUTA MÉDICA
            </a>
          </Link>

          <nav className="hidden md:flex gap-8">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a
                  className={cn(
                    "text-sm font-medium uppercase tracking-widest hover:text-primary/70 transition-colors relative group",
                    location === item.href ? "text-primary" : "text-muted-foreground"
                  )}
                >
                  {item.label}
                  <span className={cn(
                    "absolute -bottom-1 left-0 w-0 h-[1px] bg-primary transition-all duration-300 group-hover:w-full",
                    location === item.href ? "w-full" : ""
                  )} />
                </a>
              </Link>
            ))}
          </nav>

          <Link href="/contato">
            <a className="hidden md:inline-flex items-center justify-center px-6 py-2 text-sm font-bold uppercase tracking-widest border border-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300">
              Agendar Reunião
            </a>
          </Link>
        </div>
      </header>

      <main className="flex-grow pt-20">
        {children}
      </main>

      <footer className="bg-black text-white py-20 border-t border-neutral-800">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <h2 className="text-3xl font-black tracking-tighter mb-6">PAUTA MÉDICA</h2>
              <p className="text-neutral-400 max-w-md text-lg font-light">
                Assessoria de imprensa estratégica especializada em saúde. Conectando ciência e mídia com autoridade e evidência.
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-bold uppercase tracking-widest mb-6 text-neutral-500">Menu</h3>
              <ul className="space-y-4">
                {navItems.map((item) => (
                  <li key={item.href}>
                    <Link href={item.href}>
                      <a className="text-neutral-300 hover:text-white transition-colors">{item.label}</a>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-sm font-bold uppercase tracking-widest mb-6 text-neutral-500">Contato</h3>
              <ul className="space-y-4 text-neutral-300">
                <li>contato@pautamedica.com.br</li>
                <li>São Paulo, SP</li>
                <li>(11) 99999-9999</li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-neutral-900 flex flex-col md:flex-row justify-between items-center text-neutral-500 text-sm">
            <p>&copy; {new Date().getFullYear()} Pauta Médica. Todos os direitos reservados.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
              <a href="#" className="hover:text-white transition-colors">Instagram</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
